# ninerTransitDataAnalysis

Niner Transit Analysis Project
CSCI-4155 Capstone Project - UNCC Niner Transit Data Analysis Application

Group 4: Network Data Solutions - Cameron Pacileo Chase Moeller Jonathan Martinez Zack Gerald Jared Beightol Casey Oates

DEPENDECIES TO INSTALL BEFORE RUNNING
``` Python
pip install flask_sqlalchemy flask_wtf bcrypt email_validator 

``` 
